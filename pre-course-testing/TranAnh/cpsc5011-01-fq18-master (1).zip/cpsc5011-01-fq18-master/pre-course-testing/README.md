 This folder is for students to try the process of
 * Clone the repository
 * Create a directory identifiable with their name
 * Create an Eclipse Java project in that directory
 * Commit and push the directory and new project
 By the first day of class there should be a directory for each student.
 By the way, *clean your project* before commiting it, we really don't want to see your .class files!
