// Alex Peterson
// CPSC 5011 pre-course test project
// Instructor Steven Hanks

public class JibJab {

	public static void main(String[] args) {
		System.out.println("Jibber Jabber");
	}

}
